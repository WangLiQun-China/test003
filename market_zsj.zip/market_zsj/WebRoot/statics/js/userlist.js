/**
 * 
 */
var userobj;
//把隐藏的div显示
function openYesOrNoDLG(){
	$(".zhezhao").css("display","block");//显示
	$("#removeUse").fadeIn();//淡入
}
//把显示的div隐藏
function cancleBtn(){
	$(".zhezhao").css("display","none");//显示
	$("#removeUse").fadeOut();//淡出
}
//改变p标签提示的内容
function changeDLGContent(contentStr){
	//获取p标签
	var p=$(".removeMain").find("p");
	p.html(contentStr);
}

//删除(参数是指当前处理的对象)
function deleteuser(obj){
	$.ajax({
		url:path+"/sys/user/deleteuser",
		type:"get",
		data:{id:obj.attr("userid")},
		dataType:"JSON",//返回json形式，注意回调方式别写错
		success:function(data){
			//删除成功
			if(data.delResult=="true"){
				cancleBtn();//隐藏提示
				obj.parents("tr").remove();//该对在该页面移除
			}else if(data.delResult=="false"){
				changeDLGContent("删除"+obj.attr("username")+"用户失败");
			}else if(data.delResult=="notexist"){
				changeDLGContent("用户"+obj.attr("username")+"不存在");
			}
		},
		error:function(data){
			changeDLGContent("对不起,删除"+obj.attr("username")+"用户失败");
		}
		
	})
}


$(function(){
	
	
	//点击删除的时候
	$(".deleteUser").click(function(){
		userobj=$(this);
		//改变提示内容
		changeDLGContent("你确定要删除订单【"+userobj.attr("username")+"】吗？");
		openYesOrNoDLG();//显示提示框
	})
	//点击取消时
	$("#no").click(function(){
		//取消就把提示框隐藏
		cancleBtn();
	})
	//点击确认时
	$("#yes").click(function(){
		//走ajax
		deleteuser(userobj);
	})
	
	//点击查看
	$(".viewUser").click(function(){
		//获取要处理的对象（tr）
		userobj=$(this);
		window.location.href=path+"/sys/user/userView/"+userobj.attr("userid");
	})
	
	//点击修改（修改前查看）
	$(".modifyUser").click(function(){
		//获取要处理的对象（tr）
		userobj=$(this);
		window.location.href=path+"/sys/user/modifyuser/"+userobj.attr("userid");
	})
	
	
})