/**
 * 
 */
var billobj;
//把隐藏的div显示
function openYesOrNoDLG(){
	$(".zhezhao").css("display","block");//显示
	$("#removeBi").fadeIn();//淡入
}
//把显示的div隐藏
function cancleBtn(){
	$(".zhezhao").css("display","none");//显示
	$("#removeBi").fadeOut();//淡出
}
//改变p标签提示的内容
function changeDLGContent(contentStr){
	//获取p标签
	var p=$(".removeMain").find("p");
	p.html(contentStr);
}

//删除(参数是指当前处理的对象)
function deleteBill(obj){
	$.ajax({
		url:path+"/sys/bill/deletebill",
		type:"get",
		data:{billid:obj.attr("billid")},
		dataType:"JSON",//返回json形式，注意回调方式别写错
		success:function(data){
			//删除成功
			if(data.delResult=="true"){
				cancleBtn();//隐藏提示
				obj.parents("tr").remove();//该对在该页面移除
			}else if(data.delResult=="false"){
				changeDLGContent("删除"+obj.attr("billcc")+"订单失败");
			}else if(data.delResult=="notexist"){
				changeDLGContent("订单"+obj.attr("billcc")+"不存在");
			}
		},
		error:function(data){
			changeDLGContent("对不起,删除"+obj.attr("billcc")+"订单失败");
		}
		
	})
}


$(function(){
	
	//点击删除的时候
	$(".deleteBill").click(function(){
		billobj=$(this);
		//改变提示内容
		changeDLGContent("你确定要删除订单【"+billobj.attr("billcc")+"】吗？");
		openYesOrNoDLG();//显示提示框
	})
	//点击取消时
	$("#no").click(function(){
		//取消就把提示框隐藏
		cancleBtn();
	})
	//点击确认时
	$("#yes").click(function(){
		//走ajax
		deleteBill(billobj);
	})
	
	//点击查看
	$(".viewBill").click(function(){
		//获取要处理的对象（tr）
		billobj=$(this);
		window.location.href=path+"/sys/bill/viewbill/"+billobj.attr("billid");
	})
	
	
	
	//点击修改（修改前查看）
	$(".modifyBill").click(function(){
		//获取要处理的对象（tr）
		billobj=$(this);
		window.location.href=path+"/sys/bill/modifybill/"+billobj.attr("billid");
	})
	
	
	
})