var oldpassword = null;
var newpassword = null;
var rnewpassword = null;
var sk1=false;
var sk2=false;
var sk3=false;
$(function(){
	oldpassword = $("#oldpassword");
	newpassword = $("#newpassword");
	rnewpassword = $("#rnewpassword");

	
	oldpassword.next().html("*");
	newpassword.next().html("*");
	rnewpassword.next().html("*");
	//当旧密码失去光标时
	$("#oldpassword").blur(function(){
		sk1=false;
		oldpassword.next().css("color","red");
		//判断密码是否正确
		$.ajax({
			type:"get",
			url:path+"/sys/user/confirmpwd",
			data:{oldpassword:oldpassword.val()},
			dataType:"JSON",
			success:function(data){
				//失败
				if(data.pwresult=="no"){
					oldpassword.next().html("错误，请重新登录");
				}
				//登录超时
				else if(data.pwresult=="noexist"){
					oldpassword.next().html("登录超时");
				}
				//密码错误
				else if(data.pwresult=="false"){
					oldpassword.next().html("密码错误");
				}else if(data.pwresult=="true"){
					sk1=true;
					oldpassword.next().css("color","green");
					oldpassword.next().html("√");
				}
			},
			error:function(data){
				alert("对不起修改密码失败！");
			}
		})
	})
	
	//新密码失去光标时
	$("#newpassword").blur(function(){
		sk2=false;
		sk3=false;
		//初始提示变回红色
		newpassword.next().css("color","red");
		rnewpassword.next().css("color","red");
		var reg=/^[a-zA-Z0-9]{7,16}$/;
		//获取两个密码值判断
		newp=newpassword.val();
		rnp=rnewpassword.val();
		if(reg.test(newp)){
			//如果两个密码相同
			if(newp==rnp&&newpassword.length!=0){
				sk2=true;
				sk3=true;
				newpassword.next().css("color","green");
				rnewpassword.next().css("color","green");
				newpassword.next().html("√");
				rnewpassword.next().html("√");
			}else{
				newpassword.next().html("√");
				rnewpassword.next().html("密码不同");
			}
		}else{
			newpassword.next().html("大于6位小于16位");
			rnewpassword.next().html("密码不同");
		}
	})
	
	//确认密码失去光标
	$("#rnewpassword").blur(function(){
		sk2=false;
		sk3=false;
		//初始提示变回红色
		newpassword.next().css("color","red");
		rnewpassword.next().css("color","red");
		var reg=/^[a-zA-Z0-9]{7,16}$/;
		//获取两个密码值判断
		newp=newpassword.val();
		rnp=rnewpassword.val();
		if(reg.test(rnp)){
			//如果两个密码相同
			if(newp==rnp&&newpassword.length!=0){
				sk2=true;
				sk3=true;
				newpassword.next().css("color","green");
				rnewpassword.next().css("color","green");
				newpassword.next().html("√");
				rnewpassword.next().html("√");
			}else{
				newpassword.next().html("密码不同");
				rnewpassword.next().html("√");
			}
		}else{
			newpassword.next().html("密码不同");
			rnewpassword.next().html("大于6位小于16位");
		}
	})
	//点击保存按钮
	$("#save").click(function(){
		if(sk1==true&&sk2==true&&sk3==true){
			$("#userForm").submit();
		}else{
			alert("请正确填写");
		}
	})
	
});