// JavaScript Document
$(function(){
	var span2s=$('.span2');
	var monthly_dates=$('.monthly_date');
	span2s.each(function(index, element) {
        $(this).datepicker({
			format:"yyyy-mm-dd"	
		});
    });
	monthly_dates.each(function(index, element) {
        $(this).datepicker({
			format:"yyyy-mm"	
		});
    });
		
});

dsf









