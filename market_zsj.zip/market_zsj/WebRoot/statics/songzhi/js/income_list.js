// JavaScript Document
$(function(){
	var span2s=$('.span2');
	span2s.each(function(index, element) {
        $(this).datepicker({
			format:"yyyy-mm-dd"	
		});
    });
	
		
});















