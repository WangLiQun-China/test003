package cn.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.jbit.market.bean.User;
import cn.jbit.market.service.UserService;

public class TestExit {

	public static void main(String[] args) {
		ApplicationContext application=
				new ClassPathXmlApplicationContext("applicationContext.xml");
		UserService userService=(UserService) application.getBean("userService");
		try {
			User user=userService.uexist("admin");

			System.out.println(user.getId());
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
