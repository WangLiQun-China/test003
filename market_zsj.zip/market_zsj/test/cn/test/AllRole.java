package cn.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.jbit.market.bean.Role;
import cn.jbit.market.service.RoleService;

public class AllRole {

	public static void main(String[] args) {
		ApplicationContext a=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		RoleService roleService=(RoleService)a.getBean("roleService");
		
		try {
			List<Role> list=roleService.allRole();
			for(Role li:list){
				System.out.println(li.getRoleName());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
