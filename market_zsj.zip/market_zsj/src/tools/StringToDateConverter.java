package tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;

public class StringToDateConverter implements Converter<String,Date> {

	private String dataPattern;
	
	public StringToDateConverter(String dataPattern) {
		super();
		this.dataPattern = dataPattern;
	}

	@Override
	public Date convert(String arg0) {
		Date date=null;
		try {
			date=new SimpleDateFormat(dataPattern).parse(arg0);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	

}
