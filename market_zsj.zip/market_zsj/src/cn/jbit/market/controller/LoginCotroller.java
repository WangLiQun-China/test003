package cn.jbit.market.controller;

import java.io.PrintWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.jbit.market.bean.User;
import cn.jbit.market.service.UserService;

@Controller
@RequestMapping("/login")
public class LoginCotroller {

	@Resource
	private UserService userService;
	
	
	/**
	 * 登录
	 * @param userCode
	 * @param userPassword
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/doLogin",method=RequestMethod.POST)
	public String doLogin(@RequestParam String userCode,@RequestParam String userPassword,
			HttpSession session,HttpServletRequest request){
		User user=null;
		System.out.println("============已经进行用户登录判断==========");
		
		try {
			
			System.out.println("用户code："+userCode+"密码："+userPassword);
			
			
			
			
			user=userService.uexist(userCode);
			
			if(user!=null){
				if(user.getUserPassword().equals(userPassword)){
					
					//会话设置
					session.setAttribute("userCode", userCode);//用户登录账号
					session.setAttribute("userPassword", userPassword);//密码
					session.setAttribute("userName", user.getUserName());//用户名
					session.setAttribute("userUNId", user.getId());//全局id，用于修改密码获取
					session.setAttribute("login_user", user);
					session.setMaxInactiveInterval(60*30);//登录有效时间半小时
					return "frame";
				}
			
			}else{
				session.setAttribute("error", "用户名或密码不正确");
				return "redirect:../login.jsp";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.setAttribute("error", "用户名或密码不正确");
		return "redirect:../login.jsp";
		
	}

	@RequestMapping("/loginout")
	public String loginout(HttpSession session){
		//会话移除对象
		session.removeAttribute("userCode");
		session.removeAttribute("userPassword");
		session.removeAttribute("userName");
		session.removeAttribute("login_user");	
		return "redirect:../login.jsp";
	}
}
