package cn.jbit.market.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;

import cn.jbit.market.bean.Provider;
import cn.jbit.market.service.ProviderService;

@Controller
@RequestMapping("/sys/pro")
public class ProviderController {

	@Resource
	private ProviderService providerService;
	private Provider pro=null;
	private List list=null;
	private String toproviderList="redirect:/sys/pro/providerList";
	/**
	 * 所有供应商
	 * 初始页
	 * @param model
	 * @return
	 */
	@RequestMapping("/providerList")
	public String allPro(Model model){
		try {
			list=this.providerService.select_allprovider();
			model.addAttribute("providerList",list);
			model.addAttribute("provider",pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "providerlist";
	}
	/**
	 * 删除工供应商
	 * @param proid
	 * @return
	 */
	@RequestMapping("/deletepro")
	@ResponseBody
	public Object deletePro(@RequestParam String proid){
		HashMap<String,String> result=new HashMap<>();
		try {
			if(this.providerService.deletepro(Integer.valueOf(proid))){
				result.put("delResult", "true");
			}else{
				result.put("delResult", "false");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONArray.toJSONString(result);
	}
	
	/**
	 * 供应商view
	 * @param proid
	 * @param model
	 * @return
	 */
	@RequestMapping("/viewPro/{proid}")
	public String viewPro(@PathVariable String proid ,Model model){
		try {
			pro=this.providerService.viewPro(Integer.valueOf(proid));
			model.addAttribute("provider",pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "providerview";
	}
	
	/**
	 * 增加前
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/addPro",method=RequestMethod.GET)
	public String addPro(Model model){
		try {
			model.addAttribute("provider",pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "provideradd";
	}
	/**
	 * 增加保存
	 * @param pro
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/addPro",method=RequestMethod.POST)
	public String savePro(Provider pro,HttpSession session){
		pro.setCreatedBy(Integer.parseInt(session.getAttribute("userUNId").toString()));
		
		try {
			if(this.providerService.addPro(pro)){
				return toproviderList;
			}else{
				return "provideradd";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "provideradd";
	}
	/**
	 * 更改前
	 * @param proid
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/modifyPro/{proid}",method=RequestMethod.GET)
	public String modifyPro(@PathVariable String proid , Model model){
		try {
			pro=this.providerService.viewPro(Integer.valueOf(proid));
			model.addAttribute("provider",pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "providermodify";
	}
	/**
	 * 更改保存
	 * @param pro
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/modifyPro",method=RequestMethod.POST)
	public String modifyProSave(Provider pro,HttpSession session){
		pro.setModifyBy(Integer.parseInt(session.getAttribute("userUNId").toString()));
		try {
			if(this.providerService.modifyPro(pro)){
				
				return toproviderList;
			}
			else{
				return "providermodify";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "providermodify";
	}
	
	@RequestMapping(value="/fuzzyquery",method=RequestMethod.POST)
	public String fuzzyquery(Provider pro, Model model){
		try {
			list=this.providerService.fuzzyquery(pro);
			model.addAttribute("providerList",list);
			model.addAttribute("provider",pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "providerlist";
	}
	
	
}
