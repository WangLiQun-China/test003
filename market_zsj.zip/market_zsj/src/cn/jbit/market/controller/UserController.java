package cn.jbit.market.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.mysql.jdbc.StringUtils;

import cn.jbit.market.bean.Pagging;
import cn.jbit.market.bean.User;
import cn.jbit.market.service.RoleService;
import cn.jbit.market.service.UserService;

@Controller
@RequestMapping("/sys/user")
public class UserController {
	@Resource
	private UserService userService;
	@Resource
	private RoleService roleService;
	
	private String initUserlist="redirect:/sys/user/userlist?method=query";
	//实体
	User user=null;
	Pagging pag=null;
	List<User> list=null;
	
	/**
	 * 初始化和模糊搜索
	 * @param queryname
	 * @param queryUserRole
	 * @param method
	 * @param model
	 * @return
	 */
	@RequestMapping("userlist")
	public String userlist(@RequestParam(value="queryname",required=false) String queryname,
						@RequestParam(value="queryUserRole",required=false) String queryUserRole,
						@RequestParam(value="method",required=false) String method,Model model){
		
		try {
			list=roleService.allRole();
			model.addAttribute("roleList", list);
			pag=userService.count();//用户总数
			int counts=pag.getCount();//用户总数
			//总页数设置
			if(counts%5!=0){
				counts=counts/5+1;
			}else{
				counts=counts/5;
			}
			//初始页、首页
			if(method.equals("query")||method==null||method.equals("")){
				pag=new Pagging();
				pag.setPid(1);//设置页次1
				pag.setAllcounts(counts);//放置总页数
				Map<String, Integer> map=new HashMap<String, Integer>();
				map.put("m1", 0);
				map.put("m2", 5);
				list=userService.pageUser(map);
				//共享用户集合
				model.addAttribute("userList", list);
				model.addAttribute("pag", pag);
				
			}
			//搜索查询
			else if(method.equals("query2")){
				if(queryname.length()==0&&queryUserRole.equals("0")){
					pag=new Pagging();
					pag.setPid(1);//设置页次1
					pag.setAllcounts(counts);//放置总页数
					Map<String, Integer> map2=new HashMap<String, Integer>();
					map2.put("m1", 0);
					map2.put("m2", 5);
					list=userService.pageUser(map2);	
					model.addAttribute("userList", list);
					model.addAttribute("pag", pag);

				}else{
					pag=new Pagging();
					pag.setPid(1);//设置页次1
					pag.setAllcounts(counts);//放置总页数
					user=new User();
					user.setUserName(queryname);
					user.setUserRole(Integer.valueOf(queryUserRole));
					list=userService.fuzzyquery(user);
					//共享用户集合
					model.addAttribute("userList", list);
					model.addAttribute("pag", pag);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "userlist";
	}

	/**
	 * 分页
	 * @param method
	 * @param pid
	 * @param inputPage
	 * @param model
	 * @return
	 */
	@RequestMapping("/pagelist")
	public String pagelist(@RequestParam String method,
							@RequestParam(value="pid",required=false) String pid,
							@RequestParam(value="inputPage",required=false) String inputPage,Model model){
		try {
			list=roleService.allRole();
			model.addAttribute("roleList", list);
			pag=userService.count();//用户总数
			int counts=pag.getCount();//用户总数
			//总页数设置
			if(counts%5!=0){
				counts=counts/5+1;
			}else{
				counts=counts/5;
			}
			//下一页、上一页、最后一页
			if(method.equals("next")||method.equals("pre")||method.equals("fin")){
				pag=new Pagging();
				int num=Integer.valueOf(pid);//对页次转换
				pag.setPid(num);//放置页次
				pag.setAllcounts(counts);//放置总页数
				Map<String, Integer> map=new HashMap<String, Integer>();
				map.put("m1", 5*num-5);
				map.put("m2", 5);
				list=userService.pageUser(map);
				//共享用户集合
				model.addAttribute("userList", list);
				model.addAttribute("pag", pag);
		
			}
			//跳转页设置
			else if(method.equals("pagego")){
				pag=new Pagging();
				int num=Integer.valueOf(inputPage);
				if(num>counts){
					num=counts;
				}
				pag.setPid(num);//放置页次
				pag.setAllcounts(counts);//放置总页数
				Map<String, Integer> map=new HashMap<String, Integer>();
				map.put("m1", 5*num-5);
				map.put("m2", 5);
				list=userService.pageUser(map);
				//共享用户集合
				model.addAttribute("userList", list);
				//共享对象
				model.addAttribute("pag", pag);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "userlist";
	}
	
	
	
	/**
	 * 跳到添加页面
	 * @param user
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/adduser",method=RequestMethod.GET)
	public String addUser(@ModelAttribute User user,Model model){
		try {
			list=roleService.allRole();//赋予身份下拉框
			model.addAttribute("roleList", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "useradd";
	}
	/**
	 * 用户保存
	 * @param user
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/saveuser",method=RequestMethod.POST)
	public String saveuser(@Valid User user,BindingResult bindingresult,@RequestParam(value="attachs",required=false)MultipartFile[] attachs,
			HttpSession session,HttpServletRequest request,Model model) {
		String idPicPath=null;
		String wopicPath=null;
		String errorInfo=null;
		if(bindingresult.hasErrors()){//校验
			System.out.println("=========has valid go=============================");
			try {
				list=roleService.allRole();
			} catch (Exception e) {
				e.printStackTrace();
			}//赋予身份下拉框
			model.addAttribute("roleList", list);
			return "useradd";	
		}
		//定义上传目标路径
		String path=request.getRealPath("/statics");
		path=path+"/uploadfiles";
		for(int i=0;i<attachs.length;i++){
			MultipartFile attach=attachs[i];
			if(i==0){
				errorInfo="idPicPatherror";
			}else if(i==1){
				errorInfo="wopicPatherror";
			}
			//判断文件是否为空
			if(!attach.isEmpty()){
				String oldFileName=attach.getOriginalFilename();//获取原文件名
				String suffix=FilenameUtils.getExtension(oldFileName);//获取原文件名后缀
				if(attach.getSize()>5000000){//判断上传大小
					model.addAttribute(errorInfo,"上传大小不能大于500k");
					return "useradd";
				}else if(suffix.equalsIgnoreCase("jpg")||suffix.equalsIgnoreCase("jpeg")
						||suffix.equalsIgnoreCase("png")||suffix.equalsIgnoreCase("pneg")){//图片格式判读
					//当前系统日期+随机数+"_Personal.jpg"
					String fileName=System.currentTimeMillis()+RandomUtils.nextInt(1000000)+"_Personal.jpg";
					File targetFile=new File(path,fileName);
					if(!targetFile.exists()){//判断文件是否存在，不存在就创建
						targetFile.mkdirs();
					}
					try {
						attach.transferTo(targetFile); //传文件资源
					} catch (Exception e) {	
						e.printStackTrace();
						model.addAttribute(errorInfo,"上传失败");
						return "useradd";
					} 
					if(i==0){
						idPicPath=path+"/"+fileName;//要保存路径
					}else if(i==1){
						wopicPath=path+"/"+fileName;//要保存路径
					}
					
				}else{
					model.addAttribute(errorInfo,"上传必须是图片格式");
					return "useradd";
				}
			}
		}
		
		user.setIdPicPath(idPicPath);
		user.setWopicPath(wopicPath);
		user.setCreationDate(new Date());
		user.setCreatedBy(Integer.parseInt(session.getAttribute("userUNId").toString()));//获取操作人的id
		try {
			if(userService.addUser(user)){
				return "redirect:/sys/user/userlist?method=query";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "useradd";	
		
		
	}

	/**
	 * 更改前查看
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/modifyuser/{id}",method=RequestMethod.GET)
	public String modifyView(@PathVariable String id,Model model){
		
		try {
			list=roleService.allRole();//赋予身份下拉框
			model.addAttribute("roleList", list);
			user=userService.viewUser(Integer.valueOf(id));
			model.addAttribute("user", user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "usermodify";
	}
	
	/**
	 * 更改后保存
	 * @param user
	 * @param session
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/modifyuser",method=RequestMethod.POST)
	public String modifysave(User user,HttpSession session,Model model){
		
		try {
			user.setModifyBy(Integer.parseInt(session.getAttribute("userUNId").toString()));
			user.setModifyDate(new Date());
			if(userService.modifyuser(user)){
				return "redirect:/sys/user/userlist?method=query";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "usermodify";
	}

	/**
	 * 查看用户view
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping("/userView/{id}")
	public String userView(@PathVariable String id,Model model){
		try {
			user=userService.viewUser(Integer.valueOf(id));
			model.addAttribute("user", user);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "userview";
	}


	@RequestMapping("/uexist")
	@ResponseBody
	public Object uexist(@RequestParam String userCode){
		HashMap<String,String> result=new HashMap<>();
		if(StringUtils.isNullOrEmpty(userCode)){
			result.put("userCode","exist");
		}else{
			try {
				user=userService.uexist(userCode);
				if(user!=null){
					result.put("userCode","exist");
				}else{
					result.put("userCode","noexist");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(result);
	}
	/**
	 * 删除用户
	 * @param id
	 * @return
	 */
	@RequestMapping("/deleteuser")
	@ResponseBody
	public Object deleteUser(@RequestParam String id){
		HashMap<String,String> result=new HashMap<>();
		try {
			if(userService.deleteuser(Integer.valueOf(id))){
				result.put("delResult", "true");
			}else{
				result.put("delResult", "false");
			}
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return JSONArray.toJSONString(result);
	}
	
	@RequestMapping(value="/modifypwd",method=RequestMethod.GET)
	public String modifyPwdsee(@Valid String id,Model model){
		user=null;
		model.addAttribute("user",user);
		return "pwdmodify";
	}
	
	@RequestMapping(value="confirmpwd")
	@ResponseBody
	public Object confirmpwd(@RequestParam String oldpassword,HttpSession session){
		System.out.println("旧密码判断============");
		HashMap<String,String> result=new HashMap<>();
		String  userPassword=(String)session.getAttribute("userPassword");
		if(userPassword.equals(oldpassword)){
			result.put("pwresult", "true");
		}else{
			result.put("pwresult", "false");
		}
		return JSONArray.toJSONString(result);
	}
	
	@RequestMapping(value="/modifypwd",method=RequestMethod.POST)
	public String modifyPwdSave(User user,Model model,HttpSession session){
		try {
			if(userService.modifyPwd(user)){
				session.removeAttribute("userPassword");
				session.setAttribute("userPassword", user.getUserPassword());
				return "frame";
			}else{
				model.addAttribute("message","修改失败");
				return "pwdmodify";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "frame";
	}
	
}
