package cn.jbit.market.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import cn.jbit.market.bean.Bill;
import cn.jbit.market.service.BillService;
import cn.jbit.market.service.ProviderService;

@Controller
@RequestMapping("/sys/bill")
public class BillController {
	
	@Resource
	private BillService billService;
	@Resource
	private ProviderService providerService;
	
	List list=null;
	Bill bill=null;
	String tobilllist="redirect:/sys/bill/billlist";
	/**
	 * 初始订单页
	 * @param model
	 * @return
	 */
	@RequestMapping("/billlist")
	public String billlist(Model model){
		try {
			
			list=this.billService.select_allbill();
			model.addAttribute("billList", list);
			//供应商下拉框
			list=this.providerService.select_allprovider();
			model.addAttribute("providerList", list);
			model.addAttribute("bill", bill);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billlist";
	}
	/**
	 * 订单模糊查询
	 * @param bill
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/fuzzyquery",method=RequestMethod.POST)
	public String fuzzyquery(Bill bill,Model model){
		try {
			list=this.billService.fuzzyquery(bill);
			model.addAttribute("billList", list);
			//供应商下拉框
			list=this.providerService.select_allprovider();
			model.addAttribute("providerList", list);
			model.addAttribute("bill", bill);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return "billlist";
	}
	
	/**
	 * 添加前
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/addbill",method=RequestMethod.GET)
	public String addsee(Model model){
		
		try {
			model.addAttribute("bill", bill);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billadd";
	}
	/**
	 * 添加保存
	 * @param bill
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/addbill",method=RequestMethod.POST)
	public String addsave(Bill bill,Model model,HttpSession session){
		bill.setCreatedBy(Integer.parseInt(session.getAttribute("userUNId").toString()));
		try {
			if(this.billService.addBill(bill)){
				return tobilllist;
			}else{
				return "billadd";
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billadd";
	}
	/**
	 * 异步供应商
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/seepro",produces={"application/json;charset=UTF-8"})
	@ResponseBody
	public Object seepro(Model model){
		try {
			list=this.providerService.select_allprovider();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return JSON.toJSONString(list);
	}
	/**
	 * 删除订单
	 * @param billid
	 * @return
	 */
	@RequestMapping(value="/deletebill",method=RequestMethod.GET)
	@ResponseBody
	public Object deletebill(@RequestParam String billid){
		HashMap<String,String> Result=new HashMap<>();
		try {
			if(this.billService.deletBill(Integer.valueOf(billid))){
				Result.put("delResult", "true");
			}else{
				Result.put("delResult", "false");
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return JSONArray.toJSONString(Result);
	}
	/**
	 * 订单view
	 * @param billid
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/viewbill/{billid}",method=RequestMethod.GET)
	public Object viewbill(@PathVariable String billid,Model model){
		
		try {
			bill=this.billService.billView(Integer.valueOf(billid));
			model.addAttribute("bill", bill);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billview";
	}
	
	/**
	 * 修改前
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/modifybill/{billid}",method=RequestMethod.GET)
	public String modifysee(@PathVariable String billid,Model model){
		try {
			bill=this.billService.billView(Integer.valueOf(billid));
			model.addAttribute("bill", bill);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billmodify";
	}
	
	@RequestMapping(value="/modifybill",method=RequestMethod.POST)
	public String modifysave(Bill bill,HttpSession session){
		bill.setModifyBy(Integer.parseInt(session.getAttribute("userUNId").toString()));
		try {
			if(this.billService.modifyBill(bill)){
				return tobilllist;
			}else{
				return "billmodify";
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "billmodify";
	}
	
}
