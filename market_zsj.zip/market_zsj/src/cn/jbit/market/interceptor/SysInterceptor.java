package cn.jbit.market.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import cn.jbit.market.bean.User;
/**
 * 拦截器
 * @author Administrator
 *
 */
public class SysInterceptor extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session=request.getSession();
		User user=(User)session.getAttribute("login_user");
		if(user==null){//如果登录超时，或没登录
			session.setAttribute("error","请重新登录");
			response.sendRedirect(request.getContextPath()+"/login.jsp");
			return false;
		}
		return true;
	}
}
