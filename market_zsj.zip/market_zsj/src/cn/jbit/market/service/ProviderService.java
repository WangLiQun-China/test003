package cn.jbit.market.service;

import java.util.List;
import java.util.Map;

import cn.jbit.market.bean.Provider;

public interface ProviderService {
	//查看所有供应商
	public List select_allprovider() throws Exception;

	//删除供应商
	public boolean deletepro(int value)throws Exception;
	//view查看
	public Provider viewPro(int value)throws Exception;
	//增加
	public boolean addPro(Provider pro)throws Exception;
	//更新
	public boolean modifyPro(Provider pro)throws Exception;
	//模糊查询
	public List fuzzyquery(Provider pro) throws Exception;
}
