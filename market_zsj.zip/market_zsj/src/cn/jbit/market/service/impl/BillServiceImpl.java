package cn.jbit.market.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.jbit.market.bean.Bill;
import cn.jbit.market.dao.BillMapper;
import cn.jbit.market.service.BillService;
@Service("billService")
@Transactional(propagation=Propagation.REQUIRED)
public class BillServiceImpl implements BillService {

	@Resource
	private BillMapper billMapper;

	List<Bill> list=null;
	Bill bill=null;
	
	@Override
	public List fuzzyquery(Bill bill) throws Exception {
		try {
			list=this.billMapper.fuzzyquery(bill);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 查询所有订单
	 */
	@Override
	public List select_allbill() throws Exception {
		try {
			list=this.billMapper.select_allbill();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	/**
	 * 添加订单
	 */
	@Override
	public boolean addBill(Bill bill) throws Exception {
		boolean bl=false;
		try {
			this.billMapper.addBill(bill);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}

	/**
	 * 删除订单
	 */
	@Override
	public boolean deletBill(int str) throws Exception {
		boolean bl=false;
		try {
			this.billMapper.deletBill(str);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}

	/**
	 * view
	 */
	@Override
	public Bill billView(int str) throws Exception {
		bill=this.billMapper.billView(str);
		return bill;
	}

	/**
	 * 修改订单
	 */
	@Override
	public boolean modifyBill(Bill bill) throws Exception {
		boolean bl=false;
		try {
			this.billMapper.modifyBill(bill);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}
	
	
}
