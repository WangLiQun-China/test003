package cn.jbit.market.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.jbit.market.bean.Provider;
import cn.jbit.market.dao.ProviderMapper;
import cn.jbit.market.service.ProviderService;

@Service("providerService")
@Transactional(propagation=Propagation.REQUIRED)
public class ProviderServiceimpl implements ProviderService {
	@Resource
	private ProviderMapper providerMapper;
	
	List list=null;
	Provider pro=null;
	/**
	 * 所有供应商
	 */
	@Override
	public List select_allprovider() throws Exception {

		list=this.providerMapper.select_allprovider();
		
		return list;
	}

	/**
	 * 删除供应商
	 */
	@Override
	public boolean deletepro(int value) throws Exception {
		boolean bl=false;
		try {
			this.providerMapper.deletepro(value);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}

	/**
	 * 供应商view
	 */
	@Override
	public Provider viewPro(int value) throws Exception {
		pro=this.providerMapper.viewPro(value);
		return pro;
	}

	/**
	 * 添加
	 */
	@Override
	public boolean addPro(Provider pro) throws Exception {
		boolean bl=false;
		try {
			this.providerMapper.addPro(pro);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}

	/**
	 * 更改供应商
	 */
	@Override
	public boolean modifyPro(Provider pro) throws Exception {
		boolean bl=false;
		try {
			this.providerMapper.modifyPro(pro);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bl;
	}
	
	/**
	 * 供应商模糊查询
	 */
	@Override
	public List fuzzyquery(Provider pro) throws Exception {
		list=this.providerMapper.fuzzyquery(pro);
		return list;
	}
}
