package cn.jbit.market.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.jbit.market.bean.Pagging;
import cn.jbit.market.bean.User;
import cn.jbit.market.dao.UserMapper;
import cn.jbit.market.service.UserService;

@Service("userService")
@Transactional(propagation=Propagation.REQUIRED)
public class UserServiceImpl implements UserService {

	@Resource
	private UserMapper userMapper;
	
	/**
	 * 所以用户
	 */
	@Override
	public List AllUser() throws Exception {
		
		List<User> list=this.userMapper.AllUser();
		return list;
	}
	
	/**
	 * 用户行数
	 */
	@Override
	public Pagging count() throws Exception {
		Pagging pagging=this.userMapper.count();
		return pagging;
	}

	/**
	 * 分页
	 */
	@Override
	public List pageUser(Map<String, Integer> map) throws Exception {
		List<User> list=this.userMapper.pageUser(map);
		return list;
	}
	
	/**
	 * 模糊查询
	 */
	
	@Override
	public List fuzzyquery(User user) throws Exception {
		List<User> list=this.userMapper.fuzzyquery(user);
		return list;
	}
	/**
	 * 删除用户
	 */
	
	@Override
	public boolean deleteuser(int value) throws Exception {
		boolean bl=false;
		try {
			this.userMapper.deleteuser(value);
			bl=true;
		} catch (Exception e) {
			
		}
		return bl;
	}
	/**
	 * 增加用户
	 */
	
	@Override
	public boolean addUser(User user) throws Exception {
		boolean bl=false;
		try {
			this.userMapper.addUser(user);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return bl;
	}
	
	/**
	 * 修改用户
	 */
	
	@Override
	public boolean modifyuser(User user) throws Exception {
		boolean bl=false;
		try {
			this.userMapper.modifyuser(user);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return bl;
	}
	
	/**
	 * 查看用户view
	 */
	@Override
	public User viewUser(int value) throws Exception {
		User user=null;
		
		user=this.userMapper.viewUser(value);
		
		return user;
	}
	
	/**
	 * 用户exist
	 */
	@Override
	public User uexist(String abc) throws Exception {
		User user=null;
		
		user=this.userMapper.uexist(abc);
		
		return user;
	}
	
	/**
	 * 修改用户密码
	 */
	@Override
	public boolean modifyPwd(User user) throws Exception {
		boolean bl=false;
		try {
			this.userMapper.modifyPwd(user);
			bl=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return bl;
	}
}
