package cn.jbit.market.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.jbit.market.bean.Role;
import cn.jbit.market.dao.RoleMapper;
import cn.jbit.market.service.RoleService;

@Service("roleService")
public class RoleServiceImpl implements RoleService {

	@Resource
	private RoleMapper roleMapper;
	
	@Override
	public List allRole() throws Exception {
		List<Role> list=this.roleMapper.allRole();
		return list;
	}

	
}
