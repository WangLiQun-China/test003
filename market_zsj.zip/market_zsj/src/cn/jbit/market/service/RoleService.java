package cn.jbit.market.service;

import java.util.List;

import cn.jbit.market.bean.Pagging;

public interface RoleService {
	public List allRole() throws Exception;
	
	
}
