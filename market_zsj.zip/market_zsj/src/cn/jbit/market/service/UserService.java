package cn.jbit.market.service;

import java.util.List;
import java.util.Map;

import cn.jbit.market.bean.Pagging;
import cn.jbit.market.bean.User;

public interface UserService {

	public List AllUser() throws Exception;
	
	//查询总行数
	public Pagging count() throws Exception;
	
	//分页查询
	public List pageUser(Map<String, Integer> map) throws Exception;
	
	//模糊查询
	public List fuzzyquery(User user) throws Exception;
	
	//删除用户
	public boolean deleteuser(int value) throws Exception;
	
	//添加
	public boolean addUser(User user) throws Exception;
	
	//修改用户
	public boolean modifyuser(User user) throws Exception;
	
	//查看view
	public User viewUser (int value) throws Exception;
	
	//判断用户是否存在
	public User uexist(String abc)throws Exception;
	//修改密码
	public boolean modifyPwd(User user) throws Exception;
	
	
}
