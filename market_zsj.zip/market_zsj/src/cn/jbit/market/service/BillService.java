package cn.jbit.market.service;

import java.util.List;
import java.util.Map;

import cn.jbit.market.bean.Bill;

public interface BillService {
	//查询（查询多个）
	public List select_allbill() throws Exception;

	//模糊查询
	public List fuzzyquery(Bill bill) throws Exception;
	
	//添加
	public  boolean addBill(Bill bill) throws Exception;
	
	//删除
	public  boolean deletBill(int str) throws Exception;
	//view
	public  Bill billView(int str) throws Exception;
	//修改
	public  boolean modifyBill(Bill bill) throws Exception;
}
