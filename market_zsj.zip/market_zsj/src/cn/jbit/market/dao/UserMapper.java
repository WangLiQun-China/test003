package cn.jbit.market.dao;

import java.util.List;
import java.util.Map;


import cn.jbit.market.bean.Pagging;
import cn.jbit.market.bean.User;

public interface UserMapper {
	//所有用户
	public List AllUser() throws Exception;
	
	//查询总行数
	public Pagging count() throws Exception;
	
	//分页查询
	public List pageUser(Map<String, Integer> map) throws Exception;
	
	//删除用户
	public int deleteuser(int value) throws Exception;
	
	//查看view
	public User viewUser (int value) throws Exception;
	//添加
	public void addUser(User user) throws Exception;
	
	//修改用户
	public int modifyuser(User user) throws Exception;
	
	//模糊查询
	public List fuzzyquery(User user) throws Exception;
	
	//修改密码
	public int modifyPwd(User user) throws Exception;
	
	//判断用户是否存在
	public User uexist(String abc)throws Exception;
	
	

}
