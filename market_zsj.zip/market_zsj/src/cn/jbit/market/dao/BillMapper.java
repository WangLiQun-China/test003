package cn.jbit.market.dao;

import java.util.List;
import java.util.Map;

import cn.jbit.market.bean.Bill;

public interface BillMapper {
	//查询（查询多个）
	public List select_allbill() throws Exception;
	//模糊查询
	public List fuzzyquery(Bill bill) throws Exception;
	
	//删除
	public  int deletBill(int str) throws Exception;
	//view
	public  Bill billView(int str) throws Exception;
	//添加
	public  int addBill(Bill bill) throws Exception;
	//修改
	public  int modifyBill(Bill bill) throws Exception;
	
	
}
