package cn.jbit.market.dao;

import java.util.List;
import java.util.Map;

import cn.jbit.market.bean.Provider;

public interface ProviderMapper {
//查看所有供应商
	public List select_allprovider() throws Exception;
	//删除供应商
	public int deletepro(int value)throws Exception;
	//view查看
	public Provider viewPro(int value)throws Exception;
	//增加
	public int addPro(Provider pro)throws Exception;
	//更新
	public int modifyPro(Provider pro)throws Exception;
	//模糊查询
	public List fuzzyquery(Provider pro) throws Exception;
	
	

}
