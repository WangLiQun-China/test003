package cn.jbit.market.dao;

import java.util.List;

public interface RoleMapper {
	public List allRole() throws Exception;

}
