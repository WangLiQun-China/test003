package cn.jbit.market.bean;

import java.io.Serializable;

/**
 * 分页实体
 * @author Administrator
 *
 */
public class Pagging implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer start;//开始
	private Integer count;//显示用户个数
	private Integer allcounts;//总页数
	private Integer pid;//目前页次
	public Pagging() {
		// TODO Auto-generated constructor stub
	}
	public Pagging(Integer start, Integer count, Integer allcounts, Integer pid) {
		super();
		this.start = start;
		this.count = count;
		this.allcounts = allcounts;
		this.pid = pid;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getAllcounts() {
		return allcounts;
	}
	public void setAllcounts(Integer allcounts) {
		this.allcounts = allcounts;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "Pagging [start=" + start + ", count=" + count + ", allcounts=" + allcounts + ", pid=" + pid + "]";
	}
	
	
	
}
